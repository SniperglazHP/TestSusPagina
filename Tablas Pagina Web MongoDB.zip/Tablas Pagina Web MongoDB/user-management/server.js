const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Configurar EJS como el motor de plantillas
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Conectar a MongoDB
mongoose.connect('mongodb://localhost:27017/user_management', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Conectado a MongoDB');
}).catch(err => {
  console.error('Error al conectar a MongoDB:', err);
});

// Definir el esquema y el modelo de usuario
const userSchema = new mongoose.Schema({
  name: String,
  password: String,
  image: String
});

const User = mongoose.model('User', userSchema);

// Ruta para listar usuarios
app.get('/', async (req, res) => {
  try {
    const users = await User.find();
    res.render('index', { users });
  } catch (err) {
    console.error('Error al obtener usuarios:', err);
    res.status(500).send('Error interno del servidor');
  }
});

// Ruta para agregar un usuario
app.post('/add', async (req, res) => {
  const { name, password, image } = req.body;
  const newUser = new User({ name, password, image });
  try {
    await newUser.save();
    res.redirect('/');
  } catch (err) {
    console.error('Error al agregar usuario:', err);
    res.status(500).send('Error interno del servidor');
  }
});

// Ruta para eliminar un usuario
app.post('/delete/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await User.findByIdAndDelete(id);
    res.redirect('/');
  } catch (err) {
    console.error('Error al eliminar usuario:', err);
    res.status(500).send('Error interno del servidor');
  }
});

// Ruta para editar un usuario
app.post('/edit/:id', async (req, res) => {
  const { id } = req.params;
  const { name, password, image } = req.body;
  try {
    await User.findByIdAndUpdate(id, { name, password, image });
    res.redirect('/');
  } catch (err) {
    console.error('Error al editar usuario:', err);
    res.status(500).send('Error interno del servidor');
  }
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
